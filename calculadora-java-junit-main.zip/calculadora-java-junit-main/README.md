# calculadora-java-junit

Objetivo: Calculadora em Java com metodos de somas e utilizando testes unitários e retornos.
Linguagem: Java
Framework: JUnit
